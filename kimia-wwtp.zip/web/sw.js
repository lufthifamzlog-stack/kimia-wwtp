// Service worker: aplikasi tetap terbuka saat offline.
const CACHE = 'wwtp-kimia-v1';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // Firebase/Firestore selalu lewat jaringan (punya cache offline sendiri)
  if (u.hostname.endsWith('googleapis.com') && !u.hostname.startsWith('fonts')) return;
  // Halaman & file aplikasi: coba jaringan dulu supaya update cepat, cadangan dari cache
  e.respondWith(fetch(e.request).then(r => {
    if (r.ok && (u.origin === location.origin || u.hostname.includes('fonts') || u.hostname === 'www.gstatic.com')) {
      const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy));
    }
    return r;
  }).catch(() => caches.match(e.request).then(m => m || caches.match('./index.html'))));
});
